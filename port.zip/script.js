$(document).ready(function() {
    // Function to get the visitor's IP address
    function getIPAddress() {
        $.getJSON("https://api.ipify.org?format=json", function(data) {
            $("#ipAddress").text("You're visiting from " + data.ip);
        });
    }

    // Call the function to get the IP address
    getIPAddress();
});



document.addEventListener("DOMContentLoaded", () => {

    // Set IP
    fetch("https://api.ipify.org?format=json")
      .then(r => r.json())
      .then(data => {
        document.getElementById("ipAddress").textContent = data.ip;
      })
      .catch(err => console.error(err));
  
    // Fetch analytics from your n8n webhook
    fetch("https://n8n.devkey.ch/webhook/0d543f38-601a-49d2-b9b8-84b2f55531a9")
      .then(r => r.json())
      .then(data => {
  
        document.getElementById("visits30").textContent =
          `${data.visits_last_30_days}`;
  
        document.getElementById("recentCountry").textContent =
          `${data.most_recent_country}`;
  
        document.getElementById("uniqueCountries").textContent =
          `${data.unique_countries}`;
  
      })
      .catch(err => {
        document.getElementById("visits30").textContent = "Unavailable";
        document.getElementById("recentCountry").textContent = "Unavailable";
        document.getElementById("uniqueCountries").textContent = "Unavailable";
        console.error(err);
      });
  
  });
  